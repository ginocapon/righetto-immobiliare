# Righetto Immobiliare — righettoimmobiliare.it
Sito web ufficiale — Padova e Provincia — Dal 1990

## Pagine
- index.html (homepage con canvas animato)
- immobili.html / immobile.html
- servizi.html / servizio-vendita.html
- chi-siamo.html / contatti.html
- blog.html / faq.html / privacy.html
- admin.html (pannello admin)
